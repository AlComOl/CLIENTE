//Suerte!


const prevBtn =document.getElementById('prevBtn').addEventListener('click',()=>{
    const img=document.getElementById('img1');
    //incremetar la imagen y poner el class list a la siguiente quitando
    img.id='img2';
    img.classList.add('active');
    console.log(img);

});
 const nextBtn =document.getElementById('nextBtn');addEventListener('click',()=>{

 });
// const indicadoresContainer =
// const autoBtn =
// const imagenes =


