"use sctrict";


let dineroGastado = 0;

let cafe = {nombre: "Manzana", precio: 1.5};
let pan = {nombre: "Pan", precio: 2.10};
let queso = {nombre: "Queso", precio: 3.8};
let manzana = {nombre: "Manzana", precio: 4.5};

// modifica tu código aquí
//podia haber hecho algo mas pero no tengo tiempo  espero tener al menos un 5  necesito mas tiempo para los examenes 

arrayCarrito=[];


function agregaAlCarrito(producto){


}

function iniciaTemporizador(){

}